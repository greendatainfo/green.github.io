/* global window */
window.someFn = function(n) {
	return 'SomeFN ' + n + ' to '+ (n+1);
};